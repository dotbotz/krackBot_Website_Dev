<!DOCTYPE html>    
<html>    
<body>    
<h2>HTML Iframes example</h2>    
<p>Use the height and width attributes to specify the size of the iframe:</p>    
<iframe src="https://www.javatpoint.com/" height="300" width="400"></iframe>    
</body>    
</html> 