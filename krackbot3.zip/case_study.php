<!DOCTYPE html>
<html>
 <head>
<!--
Project Title: Krackbot
Designed & Developed By : Krackbot
UI Design: Khaja
Started Date: 21 Sept 2020
-->
  <title> Krackbot </title>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">
  <!-- bootstrap css  -->
  <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
  <!--  animate.css-->
  <link type="text/css" rel="stylesheet" href="css/animate.css">
  <!--  style.css-->
  <link type="text/css" rel="stylesheet" href="css/style.css">
  <style>
  </style>    

 </head>
 <body>
  <header class="menu">  
 <?php $casestudy ="case" ?>       
<?php include 'includes/header.php' ?>
      
      
  </header>
<!--     header closed   -->
     
<!-- banner section start-->
    
 <section>
  <div class="container-fluid">
   <div class="container">
     <div class="row">
        <div class="col-sm-8 pt-sm-5 mt-sm-3 pt-3 mt-3">
         <div class="col-sm-11 offset-sm-1 no-padd">
        <div class="col-sm-12">
          <h4><u>Case Study of</u></h4>
            <div class="col-sm-4 no-padd">
          <img src="images/dotbotz2.png" class="img-fluid py-2" alt="dotbotz" title="dotbotz">
                </div>
            <h4><b> Cutting-Edge Innovative Product Design Studio, <br/> focusing on Digital Products</b></h4>
       </div>
        <div class="col-sm-12 about_scroll pt-3" id="scroll">
       
         <p>Lorum ipsum We ensure our best team with professional designer,  Strangers and Developers to make your product come live. We ensure our best team with professional designer,  Strangers and Developers toStrangers and Developers to make your product come live. We ensure our to make your product come live.</p>
         
         <p>We ensure our best team with professional designer,  Strangersth professional designer,  Strangersth professional designer,  Strangers and Developers to make your product come live.</p>
            
         <img src="images/html.png" class="img-fluid" alt="line" title="dotbotz">
            
        
         <h5 class="mt-5"><b>Challanges Faced</b></h5>    
         <p>Lorum ipsum We ensure our best team with professional designer,  Strangers and Developers to make your product come live. We ensure our best team with professional designer,  Strangers and Developers toStrangers and Developers to make your product come live. We ensure our to make your product come live.</p>
         
         <p>We ensure our best team with professional designer,  Strangersth professional designer,  Strangersth professional designer,  Strangers and Developers to make your product come live.</p>
            
         <h5 class="mt-5"><b>Colors Theory</b></h5>    
         <p>Lorum ipsum We ensure our best team with professional designer,  Strangers and Developers to make your product come live. We ensure our best team with professional designer,  Strangers and Developers toStrangers and Developers to make your product come live. We ensure our to make your product come live.</p>
         
         <p>We ensure our best team with professional designer,  Strangersth professional designer,  Strangersth professional designer,  Strangers and Developers to make your product come live.</p>
            
         <img src="images/ai.png" class="img-fluid" alt="line" title="dotbotz">
         <h5 class="mt-5"><b>Technical Tool Used</b></h5>    
         <p>Lorum ipsum We ensure our best team with professional designer,  Strangers and Developers to make your product come live. We ensure our best team with professional designer,  Strangers and Developers toStrangers and Developers to make your product come live. We ensure our to make your product come live.</p>
         
         <p>We ensure our best team with professional designer,  Strangersth professional designer,  Strangersth professional designer,  Strangers and Developers to make your product come live.</p>
            
         <img src="images/html.png" class="img-fluid" alt="line" title="dotbotz" style="width: 16%;">
         <img src="images/ps.png" class="img-fluid" alt="line" title="dotbotz" style="width: 16%;">
         <img src="images/ai.png" class="img-fluid" alt="line" title="dotbotz" style="width: 16%;">
         <img src="images/xd.png" class="img-fluid" alt="line" title="dotbotz" style="width: 16%;">
        </div>
         </div>
         </div>
         <div class="col-sm-4 pt-sm-2 mt-sm-2 pt-3 mt-3">
        <div class="col-sm-12">
            
            
         <div class="col-sm-12 pt-1">
          <div class="row">
           <div class="col-sm-12">
            <div class="col-sm-12">
                
           <div class="col-sm-12 bg-light br24 about_scroll1 pl-4" id="scroll">
              <img src="images/dotbotz2.png" class="img-fluid  mt-2" style="width:50%" alt="krackbot" title="services">
              <h6><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </small></h6>
                <button type="button" class="btn btn-secondary px-5 mb-3">Explore</button> <br/>
              <img src="images/totato.png" class="img-fluid  mt-2" style="width:50%" alt="krackbot" title="services">
              <h6><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </small></h6>
                <button type="button" class="btn btn-secondary px-5 mb-3">Explore</button>
                <br/>
              <img src="images/tidin.png" class="img-fluid  mt-2" style="width:35%" alt="krackbot" title="services">
              <h6><small>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </small></h6>
                <button type="button" class="btn btn-secondary px-5 mb-3">Explore</button>
             </div> 
             </div> 
          </div>    
          </div>   
         </div>        
        
         </div>
         </div>
     </div>   
   </div>   
  </div>
 </section>
    
     
<!-- banner section end-->     
     
 <!--   script tags  -->
 <script src="js/jquery.min.js"></script>
 <script src="js/popper.js"></script>
 <script src="js/bootstrap.min.js"></script>
  

<script>
 $('#grayButton').click(switchGray);
$('#whiteButton').click(switchWhite);
$('#blueButton').click(switchBlue);
$('#yellowButton').click(switchYellow);

function switchGray() {
  $('body').attr('class', 'gray');
}

function switchWhite() {
  $('body').attr('class', 'white');
}

function switchBlue() {
  $('body').attr('class', 'blue');
}

function switchYellow() {
  $('body').attr('class', 'yellow');
}
</script>
 <script>
   function toggleMenu(e) {
  e.classList.toggle("active");
  document.querySelector("aside").classList.toggle("active");
}    
 </script>
 </body>
</html>